"""
A multi-user, multi-team task management and assignment system for Django.
"""
__version__ = '0.1'

__author__ = 'Tushar Patil'
__email__ = 'patiltushar80@yahoo.com'

__license__ = 'BSD License'
